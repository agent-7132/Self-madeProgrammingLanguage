#!/bin/bash
clang -emit-llvm -c memory_model.c -o memory_model.bc
klee --libc=uclibc --posix-runtime memory_model.bc \
  --output-dir=klee-out \
  --max-time=3600 \
  --sym-mem-size=4096

python3 analyze_klee.py klee-out/
